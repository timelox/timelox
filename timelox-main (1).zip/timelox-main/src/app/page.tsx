export default function Home() {
  return (
    <main>
      <h1>Hello</h1>
    </main>
  );
}
